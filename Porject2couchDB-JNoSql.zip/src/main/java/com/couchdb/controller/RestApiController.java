package com.couchdb.controller;

import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.jnosql.diana.api.document.Document;
import org.jnosql.diana.api.document.DocumentEntity;
import org.jnosql.diana.couchdb.document.CouchDBDocumentCollectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.couchdb.config.ConfigBeans;
import com.couchdb.jnosql.repository.HeroRepository;
import com.couchdb.model.Hero;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api")
public class RestApiController {

	public static final Logger log = LoggerFactory.getLogger(RestApiController.class);

	@Autowired
	private CouchDBDocumentCollectionManager managerCouchDB;
	@Autowired
	private AnnotationConfigApplicationContext context;
//	@Autowired
//	private HeroRepository heroRepo;
	
	@RequestMapping(value = "/import/{type}", headers = "Content-Type=application/json", method = RequestMethod.POST)
	public <T> String getAcesse(@PathVariable String type, @RequestBody String data)
			throws ClassNotFoundException, JsonParseException, JsonMappingException, IOException {

		
		System.out.println(context.getBeanDefinitionCount() );
		System.out.println(context.getBeanDefinitionNames() );
		
        for (String beanName : context.getBeanDefinitionNames()) {
            System.out.println(beanName);
        }
		
		
		type = StringUtils.capitalize(type);
		String classe = "com.couchdb.model." + type;
		Class<?> clazz = Class.forName(classe);
		ObjectMapper mapper = new ObjectMapper();
		JavaType tipoClass = mapper.getTypeFactory().constructCollectionType(List.class, clazz);
		List<T> jsonToJava = mapper.readValue(data, tipoClass);

		DocumentEntity documentEntity = DocumentEntity.of(type);
		documentEntity.add(Document.of("_id", type + "_" + UUID.randomUUID().toString()));
		documentEntity.add(type, jsonToJava);
		managerCouchDB.insert(documentEntity);
		
		
//	    ClienteServico servico = context.getBean(ClienteServico.class);
//	    servico.salvar(new Cliente(1, "Aluno João da Silva"));
	    
//	    Hero heroi = context.getBean(Hero.class);
//	    servico.salvar(new Cliente(1, "Aluno João da Silva"));
		
		
		
        Hero ironMan = Hero.builder()
				.withRealName("Tony Stark").withName("iron_man").withAge(34)
				.build();
        
        
        System.out.println("Objeto: " + ironMan);


//		  Hero ironMan = Hero.builder().withRealName("Tony Stark").withName("iron_man")
//                .withAge(34).build();
//		  
//		  SeContainer container = SeContainerInitializer.newInstance().initialize();
//		  DocumentTemplate template = container.select(DocumentTemplate.class).get();
//		  template.insert(ironMan);
//		  
//        Hero ironMan = Hero.builder().withRealName("Tony Stark").withName("iron_man")
//                .withAge(34).withPowers(Collections.singleton("rich")).build();
//        DocumentTemplate template = container.select(DocumentTemplate.class).get();
//
//        template.insert(ironMan);
//
//        DocumentQuery query = select().from("Hero").where(eq(Document.of("_id", "iron_man"))).build();
//        List<Hero> heroes = template.select(query);
//        System.out.println(heroes);

		
		
		
		
//		DocumentQuery documentQuery = new CouchDBDocumentQuery(documentQuery );
		
		
		List<DocumentEntity> query = managerCouchDB.query("select * from " + type);
		
		System.out.println("============================");
		System.out.println("aqui com Factory......" + jsonToJava);//

		for (DocumentEntity hr : query) {

			List<Document> hs = hr.getDocuments().stream()
					.filter(s->s.getName().contains("Hero"))
					.collect(Collectors.toList());

			hs.forEach(System.out::println);

			System.out.println(hs.parallelStream().findFirst());
			
//			List <T> jsonToJava2 = mapper.readValue(  hs, tipoClass);
//			jsonToJava2.stream().forEach(System.out::println);			
//			
		}

//		for (Hero hero : jsonToJava) {
//			System.out.println(hero.toString());
//		}

		System.out.println("============================");

//		DocumentQuery entity  ;
//		CouchDBDocumentQuery quey = CouchDBDocumentQuery.of(null, "books");
//		List<DocumentEntity> documentsFound = collectionManager.find(query);

//        DocumentQuery query = DocumentQuery.of(COLLECTION_NAME);
//        query.and(DocumentCondition.eq(id.get()));
//        List<DocumentEntity> documentsFound = collectionManager.find(query);

//		entityManager = managerFactory.get("people");
//		Object id = entity.find(ID).map(Document::get).get();
//        DocumentQuery query = select().from(COLLECTION_NAME).where(ID).eq(id).build();
//        DocumentEntity documentFound = entityManager.singleResult(query).get();
//        
//		MangoQueryConverter converter = new MangoQueryConverter();

//		DocumentQuery query = select().from("books").where("_id").eq(100).build();
//		List<DocumentEntity> entities = manager.select(query)

//		log.info("============================="+managerFactory);

		return "oi";// heroRepository..findAll();
	}

}
