package com.couchdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;

import com.couchdb.config.ConfigBeans;

@SpringBootApplication // (scanBasePackages={"com.couchdb.*.*"})
//@EnableJpaRepositories("com.couchdb.model.DAO.repository.*.*")
//@EntityScan//("com.couchdb.model.*.*")
public class CouchDbJNoSqlApplication {

	public static void main(String[] args) {

		SpringApplication.run(CouchDbJNoSqlApplication.class, args);
//		context.close();

	}



}
