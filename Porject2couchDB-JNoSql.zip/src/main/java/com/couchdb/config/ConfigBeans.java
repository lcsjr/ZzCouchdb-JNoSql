package com.couchdb.config;

import org.jnosql.diana.couchdb.document.CouchDBDocumentCollectionManager;
import org.jnosql.diana.couchdb.document.CouchDBDocumentCollectionManagerFactory;
import org.jnosql.diana.couchdb.document.CouchDBDocumentConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.couchdb.CouchDbJNoSqlApplication;

@Configuration
public class ConfigBeans {
	
	private CouchDBDocumentConfiguration config;
	private CouchDBDocumentCollectionManagerFactory managerFactory;
	
	@Bean
	public CouchDBDocumentConfiguration config () {
		return new CouchDBDocumentConfiguration();
	}

	@Bean
	public CouchDBDocumentCollectionManagerFactory managerFactory () {
		return config.get();
	}

	@Bean
	public CouchDBDocumentCollectionManager managerNoSql () {
		return managerFactory.get("my-db");
	}
	
	@Bean
	public AnnotationConfigApplicationContext context() {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan(CouchDbJNoSqlApplication.class.getPackage().getName());
		System.out.println("abcbabcbabc");
		context.register(ConfigBeans.class);
		context.refresh();
		return context;
	}

	
	

}
